package com.example.data

import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class ExpenseRepository(
    private val transactionDao: TransactionDao,
    private val categoryDao: CategoryDao,
    private val budgetDao: BudgetDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    fun getTransactionsBetween(start: Long, end: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsBetween(start, end)

    fun getBudgetForMonth(monthKey: String): Flow<BudgetEntity?> =
        budgetDao.getBudgetForMonth(monthKey)

    suspend fun insertTransaction(transaction: TransactionEntity): Long =
        transactionDao.insertTransaction(transaction)

    suspend fun insertTransactions(transactions: List<TransactionEntity>) =
        transactionDao.insertTransactions(transactions)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        transactionDao.updateTransaction(transaction)

    suspend fun deleteTransaction(transaction: TransactionEntity) =
        transactionDao.deleteTransaction(transaction)

    suspend fun deleteTransactionById(id: Long) =
        transactionDao.deleteTransactionById(id)

    suspend fun clearAllTransactions() =
        transactionDao.clearAllTransactions()

    suspend fun setBudget(monthKey: String, amount: Double) =
        budgetDao.setBudget(BudgetEntity(monthKey = monthKey, amount = amount))

    suspend fun insertCategory(category: CategoryEntity): Long =
        categoryDao.insertCategory(category)

    suspend fun deleteCategory(category: CategoryEntity) =
        categoryDao.deleteCategory(category)

    suspend fun deleteCustomCategoryById(id: Long) =
        categoryDao.deleteCustomCategoryById(id)

    suspend fun ensureDefaultCategories() {
        if (categoryDao.getCategoryCount() == 0) {
            AppDatabase.populateInitialCategories(categoryDao)
        }
    }

    // CSV Export Generator
    fun generateCsv(transactions: List<TransactionEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Date,Type,Category,Amount,Payment Method,Note,Recurring,Frequency\n")
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
        for (tx in transactions) {
            val formattedDate = sdf.format(java.util.Date(tx.date))
            val escapedNote = "\"" + tx.note.replace("\"", "\"\"") + "\""
            sb.append("${tx.id},$formattedDate,${tx.type},\"${tx.category}\",${tx.amount},\"${tx.paymentMethod}\",$escapedNote,${tx.isRecurring},${tx.recurringFrequency}\n")
        }
        return sb.toString()
    }

    // JSON Backup Generator
    fun exportBackupJson(
        transactions: List<TransactionEntity>,
        categories: List<CategoryEntity>
    ): String {
        val root = JSONObject()
        val txArray = JSONArray()
        for (tx in transactions) {
            val obj = JSONObject()
            obj.put("id", tx.id)
            obj.put("type", tx.type)
            obj.put("amount", tx.amount)
            obj.put("category", tx.category)
            obj.put("paymentMethod", tx.paymentMethod)
            obj.put("date", tx.date)
            obj.put("note", tx.note)
            obj.put("isRecurring", tx.isRecurring)
            obj.put("recurringFrequency", tx.recurringFrequency)
            txArray.put(obj)
        }

        val catArray = JSONArray()
        for (cat in categories) {
            if (cat.isCustom) {
                val obj = JSONObject()
                obj.put("name", cat.name)
                obj.put("type", cat.type)
                obj.put("iconName", cat.iconName)
                obj.put("colorHex", cat.colorHex)
                catArray.put(obj)
            }
        }

        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("transactions", txArray)
        root.put("customCategories", catArray)
        return root.toString(2)
    }

    // JSON Restore Parser
    suspend fun restoreBackupJson(jsonString: String): Int {
        val root = JSONObject(jsonString)
        val txArray = root.optJSONArray("transactions") ?: return 0
        val catArray = root.optJSONArray("customCategories")

        if (catArray != null) {
            for (i in 0 until catArray.length()) {
                val obj = catArray.getJSONObject(i)
                val cat = CategoryEntity(
                    name = obj.getString("name"),
                    type = obj.optString("type", "EXPENSE"),
                    iconName = obj.optString("iconName", "category"),
                    colorHex = obj.optString("colorHex", "#3B82F6"),
                    isCustom = true
                )
                categoryDao.insertCategory(cat)
            }
        }

        val restoredList = mutableListOf<TransactionEntity>()
        for (i in 0 until txArray.length()) {
            val obj = txArray.getJSONObject(i)
            restoredList.add(
                TransactionEntity(
                    type = obj.getString("type"),
                    amount = obj.getDouble("amount"),
                    category = obj.getString("category"),
                    paymentMethod = obj.optString("paymentMethod", "Cash"),
                    date = obj.getLong("date"),
                    note = obj.optString("note", ""),
                    isRecurring = obj.optBoolean("isRecurring", false),
                    recurringFrequency = obj.optString("recurringFrequency", "NONE")
                )
            )
        }
        transactionDao.insertTransactions(restoredList)
        return restoredList.size
    }
}
