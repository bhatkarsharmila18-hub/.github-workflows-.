package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String = "EXPENSE", // "EXPENSE", "INCOME", "BOTH"
    val iconName: String = "category",
    val colorHex: String = "#3B82F6",
    val isCustom: Boolean = false
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey
    val monthKey: String, // e.g. "2026-10"
    val amount: Double
)
