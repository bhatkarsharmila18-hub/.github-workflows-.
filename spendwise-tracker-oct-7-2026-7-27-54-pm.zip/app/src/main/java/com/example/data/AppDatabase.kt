package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TransactionEntity::class,
        CategoryEntity::class,
        BudgetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "expense_tracker_database"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Prepopulate categories on background coroutine
                CoroutineScope(Dispatchers.IO).launch {
                    INSTANCE?.let { database ->
                        populateInitialCategories(database.categoryDao())
                    }
                }
            }
        }

        suspend fun populateInitialCategories(categoryDao: CategoryDao) {
            val defaults = listOf(
                // Expense categories
                CategoryEntity(name = "Food", type = "EXPENSE", iconName = "restaurant", colorHex = "#EF4444"),
                CategoryEntity(name = "Travel", type = "EXPENSE", iconName = "flight", colorHex = "#3B82F6"),
                CategoryEntity(name = "Shopping", type = "EXPENSE", iconName = "shopping_bag", colorHex = "#EC4899"),
                CategoryEntity(name = "Education", type = "EXPENSE", iconName = "school", colorHex = "#8B5CF6"),
                CategoryEntity(name = "Bills", type = "EXPENSE", iconName = "receipt_long", colorHex = "#F59E0B"),
                CategoryEntity(name = "Entertainment", type = "EXPENSE", iconName = "movie", colorHex = "#6366F1"),
                CategoryEntity(name = "Health", type = "EXPENSE", iconName = "medical_services", colorHex = "#10B981"),
                CategoryEntity(name = "Groceries", type = "EXPENSE", iconName = "local_grocery_store", colorHex = "#14B8A6"),
                CategoryEntity(name = "Other", type = "EXPENSE", iconName = "more_horiz", colorHex = "#6B7280"),
                // Income categories
                CategoryEntity(name = "Salary", type = "INCOME", iconName = "account_balance_wallet", colorHex = "#10B981"),
                CategoryEntity(name = "Freelance", type = "INCOME", iconName = "work", colorHex = "#06B6D4"),
                CategoryEntity(name = "Business", type = "INCOME", iconName = "store", colorHex = "#3B82F6"),
                CategoryEntity(name = "Investment", type = "INCOME", iconName = "trending_up", colorHex = "#8B5CF6"),
                CategoryEntity(name = "Gift", type = "INCOME", iconName = "card_giftcard", colorHex = "#F43F5E"),
                CategoryEntity(name = "Other Income", type = "INCOME", iconName = "attach_money", colorHex = "#10B981")
            )
            categoryDao.insertCategories(defaults)
        }
    }
}
