package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "EXPENSE" or "INCOME"
    val amount: Double,
    val category: String,
    val paymentMethod: String, // "Cash", "UPI", "Card", "Bank", "Other"
    val date: Long, // Epoch timestamp in ms
    val note: String = "",
    val isRecurring: Boolean = false,
    val recurringFrequency: String = "NONE" // "NONE", "DAILY", "WEEKLY", "MONTHLY"
)
