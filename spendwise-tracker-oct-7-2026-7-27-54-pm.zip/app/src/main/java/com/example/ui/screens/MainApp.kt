package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TransactionEntity
import com.example.ui.theme.ExpenseTrackerTheme
import com.example.ui.viewmodel.ExpenseViewModel
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch

enum class AppTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home, "tab_home"),
    TRANSACTIONS("Transactions", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "tab_transactions"),
    ADD("Add", Icons.Filled.Add, Icons.Filled.Add, "tab_add"),
    ANALYTICS("Analytics", Icons.Filled.BarChart, Icons.Outlined.BarChart, "tab_analytics"),
    SETTINGS("Budget & More", Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var currentTabIndex by remember { mutableIntStateOf(0) }
    var editingTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Back handling: If on secondary tab, back button returns to Home tab
    BackHandler(enabled = currentTabIndex != 0) {
        currentTabIndex = 0
    }

    ExpenseTrackerTheme(
        darkTheme = uiState.isDarkMode ?: androidx.compose.foundation.isSystemInDarkTheme()
    ) {
        BoxWithConstraints(modifier = modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 600.dp

            Row(modifier = Modifier.fillMaxSize()) {
                // Wide Screen Navigation Rail
                if (isWideScreen) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        AppTab.values().forEachIndexed { index, tab ->
                            NavigationRailItem(
                                selected = currentTabIndex == index,
                                onClick = { currentTabIndex = index },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTabIndex == index) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.title
                                    )
                                },
                                label = { Text(tab.title, fontSize = 11.sp) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                // Main Content
                Scaffold(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    text = when (currentTabIndex) {
                                        0 -> "Expense Tracker"
                                        1 -> "All Transactions"
                                        2 -> "Add Transaction"
                                        3 -> "Spending Analytics"
                                        else -> "Budget & Settings"
                                    },
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                titleContentColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    },
                    bottomBar = {
                        if (!isWideScreen) {
                            NavigationBar(
                                modifier = Modifier
                                    .navigationBarsPadding()
                                    .testTag("bottom_nav_bar"),
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 6.dp
                            ) {
                                AppTab.values().forEachIndexed { index, tab ->
                                    val isSelected = currentTabIndex == index
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { currentTabIndex = index },
                                        icon = {
                                            if (tab == AppTab.ADD) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .background(MaterialTheme.colorScheme.primary, shape = CircleShape),
                                                    contentAlignment = androidx.compose.ui.Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Add,
                                                        contentDescription = "Add",
                                                        tint = MaterialTheme.colorScheme.onPrimary,
                                                        modifier = Modifier.size(22.dp)
                                                    )
                                                }
                                            } else {
                                                Icon(
                                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.title
                                                )
                                            }
                                        },
                                        label = {
                                            Text(
                                                text = tab.title,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        modifier = Modifier.testTag(tab.tag),
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                        )
                                    )
                                }
                            }
                        }
                    },
                    floatingActionButton = {
                        // Show FAB on Dashboard or Transactions tab for quick add
                        if (currentTabIndex == 0 || currentTabIndex == 1) {
                            FloatingActionButton(
                                onClick = { currentTabIndex = 2 },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.testTag("global_add_fab")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add Transaction",
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    },
                    snackbarHost = {
                        SnackbarHost(hostState = snackbarHostState)
                    }
                ) { innerPadding ->
                    Crossfade(
                        targetState = currentTabIndex,
                        modifier = Modifier.padding(innerPadding),
                        label = "TabCrossfade"
                    ) { tabIndex ->
                        when (tabIndex) {
                            0 -> DashboardScreen(
                                uiState = uiState,
                                onNavigateToTransactions = { currentTabIndex = 1 },
                                onNavigateToAdd = { currentTabIndex = 2 },
                                onQuickAdd = { preset ->
                                    viewModel.quickAdd(preset) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(
                                                message = "Added ${preset.title} (${CurrencyUtils.formatInr(preset.amount)})",
                                                duration = SnackbarDuration.Short
                                            )
                                        }
                                    }
                                },
                                onTransactionClick = { tx -> editingTransaction = tx },
                                onNavigateToBudget = { currentTabIndex = 4 }
                            )
                            1 -> TransactionsScreen(
                                uiState = uiState,
                                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                onTypeFilterChange = { viewModel.setTypeFilter(it) },
                                onCategoryFilterChange = { viewModel.setCategoryFilter(it) },
                                onPaymentFilterChange = { viewModel.setPaymentFilter(it) },
                                onDateRangeFilterChange = { viewModel.setDateRangeFilter(it) },
                                onTransactionClick = { tx -> editingTransaction = tx },
                                onNavigateToAdd = { currentTabIndex = 2 }
                            )
                            2 -> AddTransactionScreen(
                                categories = uiState.categories,
                                onSaveTransaction = { type, amount, category, payment, date, note, isRec, freq ->
                                    viewModel.addTransaction(
                                        type = type,
                                        amount = amount,
                                        category = category,
                                        paymentMethod = payment,
                                        date = date,
                                        note = note,
                                        isRecurring = isRec,
                                        recurringFrequency = freq
                                    )
                                },
                                onOpenAddCategoryDialog = { showAddCategoryDialog = true },
                                onDone = { currentTabIndex = 0 }
                            )
                            3 -> AnalyticsScreen(
                                uiState = uiState,
                                onNavigateToAdd = { currentTabIndex = 2 }
                            )
                            4 -> BudgetAndReportsScreen(
                                uiState = uiState,
                                onSetMonthlyBudget = { viewModel.setMonthlyBudget(it) },
                                onOpenAddCategoryDialog = { showAddCategoryDialog = true },
                                onDeleteCustomCategory = { viewModel.deleteCustomCategory(it) },
                                onExportCsv = { viewModel.exportCsv() },
                                onExportBackupJson = { viewModel.exportBackupJson() },
                                onRestoreBackupJson = { json ->
                                    coroutineScope.launch {
                                        val count = viewModel.restoreBackupJson(json)
                                        snackbarHostState.showSnackbar("Restored $count transactions!")
                                    }
                                },
                                onClearAllData = { viewModel.clearAllData() },
                                onToggleDarkMode = { viewModel.toggleDarkMode(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Edit Transaction Dialog
    editingTransaction?.let { tx ->
        EditTransactionDialog(
            transaction = tx,
            categories = uiState.categories,
            onDismiss = { editingTransaction = null },
            onSave = { updated ->
                viewModel.updateTransaction(updated)
                editingTransaction = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Transaction updated")
                }
            },
            onDelete = { toDelete ->
                viewModel.deleteTransaction(toDelete)
                editingTransaction = null
                coroutineScope.launch {
                    val result = snackbarHostState.showSnackbar(
                        message = "Transaction deleted",
                        actionLabel = "Undo",
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        viewModel.undoDeleteTransaction()
                    }
                }
            }
        )
    }

    // Add Custom Category Dialog
    if (showAddCategoryDialog) {
        AddCategoryDialog(
            onDismiss = { showAddCategoryDialog = false },
            onSaveCategory = { name, type, iconName, colorHex ->
                viewModel.addCustomCategory(name, type, iconName, colorHex)
                showAddCategoryDialog = false
            }
        )
    }
}
