package com.example.ui.model

import androidx.compose.ui.graphics.Color
import com.example.data.CategoryEntity
import com.example.data.TransactionEntity

enum class TransactionTypeFilter(val label: String) {
    ALL("All"),
    EXPENSE("Expenses"),
    INCOME("Income")
}

enum class DateRangeFilter(val label: String) {
    ALL("All Time"),
    TODAY("Today"),
    THIS_WEEK("This Week"),
    THIS_MONTH("This Month"),
    LAST_MONTH("Last Month")
}

data class CategorySpendingStat(
    val category: String,
    val amount: Double,
    val percentage: Float, // 0..100
    val color: Color,
    val iconName: String
)

data class MonthlyStat(
    val monthKey: String,
    val monthLabel: String,
    val totalExpense: Double,
    val totalIncome: Double
)

data class ExpenseUiState(
    val transactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val currentBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val savings: Double = 0.0,
    val todayExpense: Double = 0.0,
    val thisMonthExpense: Double = 0.0,
    val monthlyBudget: Double? = null,
    val budgetSpentPercentage: Float = 0f,
    val budgetRemaining: Double = 0.0,
    val categoryStats: List<CategorySpendingStat> = emptyList(),
    val monthlyStats: List<MonthlyStat> = emptyList(),
    val searchQuery: String = "",
    val typeFilter: TransactionTypeFilter = TransactionTypeFilter.ALL,
    val categoryFilter: String? = null,
    val paymentFilter: String? = null,
    val dateRangeFilter: DateRangeFilter = DateRangeFilter.ALL,
    val isDarkMode: Boolean? = null,
    val isLoading: Boolean = false
)
