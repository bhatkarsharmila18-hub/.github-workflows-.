package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.ui.components.BudgetWarningBanner
import com.example.ui.components.EmptyStateView
import com.example.ui.components.HeroBalanceCard
import com.example.ui.components.SpendingSummaryCards
import com.example.ui.components.TransactionListItem
import com.example.ui.model.ExpenseUiState
import com.example.util.CategoryHelper
import com.example.util.CurrencyUtils
import com.example.util.QuickAddPreset

@Composable
fun DashboardScreen(
    uiState: ExpenseUiState,
    onNavigateToTransactions: () -> Unit,
    onNavigateToAdd: () -> Unit,
    onQuickAdd: (QuickAddPreset) -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onNavigateToBudget: () -> Unit,
    modifier: Modifier = Modifier
) {
    val recentTransactions = uiState.transactions.take(5)
    val catMap = uiState.categories.associateBy { it.name.lowercase() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Balance Card
        item {
            HeroBalanceCard(
                balance = uiState.currentBalance,
                totalIncome = uiState.totalIncome,
                totalExpense = uiState.totalExpense,
                savings = uiState.savings
            )
        }

        // Today & Month Spending Cards
        item {
            SpendingSummaryCards(
                todayExpense = uiState.todayExpense,
                thisMonthExpense = uiState.thisMonthExpense
            )
        }

        // Budget Warning (if close or exceeded)
        item {
            BudgetWarningBanner(
                budget = uiState.monthlyBudget,
                spent = uiState.thisMonthExpense,
                spentPercentage = uiState.budgetSpentPercentage,
                onSetBudgetClick = onNavigateToBudget
            )
        }

        // Quick-Add Presets Bar
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = "Quick Add",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Quick Add",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (preset in CategoryHelper.defaultQuickPresets) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                                .clickable { onQuickAdd(preset) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("quick_add_${preset.title.replace(" ", "_").lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = preset.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = CurrencyUtils.formatInr(preset.amount, false),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Recent Transactions Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Transactions",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (uiState.transactions.isNotEmpty()) {
                    TextButton(
                        onClick = onNavigateToTransactions,
                        modifier = Modifier.testTag("see_all_transactions_button")
                    ) {
                        Text(
                            text = "See All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // Recent Transactions List or Empty State
        if (recentTransactions.isEmpty()) {
            item {
                EmptyStateView(
                    title = "No Transactions Yet",
                    message = "Tap the + button to record your first income or daily expense.",
                    buttonText = "Add Transaction",
                    onButtonClick = onNavigateToAdd
                )
            }
        } else {
            items(recentTransactions, key = { it.id }) { tx ->
                val catEntity = catMap[tx.category.lowercase()]
                TransactionListItem(
                    transaction = tx,
                    categoryEntity = catEntity,
                    onClick = { onTransactionClick(tx) }
                )
            }
        }
    }
}
