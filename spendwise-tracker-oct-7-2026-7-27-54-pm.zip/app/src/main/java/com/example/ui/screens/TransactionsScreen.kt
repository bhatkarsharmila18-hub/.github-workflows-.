package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.TransactionListItem
import com.example.ui.model.DateRangeFilter
import com.example.ui.model.ExpenseUiState
import com.example.ui.model.TransactionTypeFilter
import com.example.util.CategoryHelper
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@Composable
fun TransactionsScreen(
    uiState: ExpenseUiState,
    onSearchQueryChange: (String) -> Unit,
    onTypeFilterChange: (TransactionTypeFilter) -> Unit,
    onCategoryFilterChange: (String?) -> Unit,
    onPaymentFilterChange: (String?) -> Unit,
    onDateRangeFilterChange: (DateRangeFilter) -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onNavigateToAdd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val catMap = remember(uiState.categories) {
        uiState.categories.associateBy { it.name.lowercase() }
    }

    // Group filtered transactions by date
    val groupedTransactions = remember(uiState.filteredTransactions) {
        uiState.filteredTransactions.groupBy { DateUtils.formatRelativeDate(it.date) }
    }

    val totalFilteredExpense = remember(uiState.filteredTransactions) {
        uiState.filteredTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    }
    val totalFilteredIncome = remember(uiState.filteredTransactions) {
        uiState.filteredTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("transactions_screen")
    ) {
        // Search Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_text_field"),
                placeholder = { Text("Search by note, category, or amount...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        // Horizontal Filter Chips: Type (All, Expense, Income)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (type in TransactionTypeFilter.values()) {
                val isSelected = uiState.typeFilter == type
                FilterChip(
                    selected = isSelected,
                    onClick = { onTypeFilterChange(type) },
                    label = { Text(type.label) },
                    modifier = Modifier.testTag("filter_type_${type.name.lowercase()}"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }

            // Date Filters
            for (dateFilter in DateRangeFilter.values()) {
                val isSelected = uiState.dateRangeFilter == dateFilter
                FilterChip(
                    selected = isSelected,
                    onClick = { onDateRangeFilterChange(dateFilter) },
                    label = { Text(dateFilter.label) },
                    modifier = Modifier.testTag("filter_date_${dateFilter.name.lowercase()}"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }

        // Category & Payment Secondary Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )

            // Category filter chips
            FilterChip(
                selected = uiState.categoryFilter == null,
                onClick = { onCategoryFilterChange(null) },
                label = { Text("All Categories") }
            )

            for (cat in uiState.categories.take(10)) {
                val isSelected = uiState.categoryFilter.equals(cat.name, ignoreCase = true)
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        onCategoryFilterChange(if (isSelected) null else cat.name)
                    },
                    label = { Text(cat.name) }
                )
            }

            // Payment filter chips
            for (method in CategoryHelper.paymentMethods) {
                val isSelected = uiState.paymentFilter.equals(method, ignoreCase = true)
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        onPaymentFilterChange(if (isSelected) null else method)
                    },
                    label = { Text(method) }
                )
            }
        }

        // Subheader Summary
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${uiState.filteredTransactions.size} transactions",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (totalFilteredIncome > 0) {
                    Text(
                        text = "+${CurrencyUtils.formatInr(totalFilteredIncome, false)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (totalFilteredExpense > 0) {
                    Text(
                        text = "-${CurrencyUtils.formatInr(totalFilteredExpense, false)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // Transactions List
        if (uiState.filteredTransactions.isEmpty()) {
            EmptyStateView(
                title = "No Transactions Found",
                message = if (uiState.searchQuery.isNotEmpty() || uiState.categoryFilter != null) {
                    "Try clearing your search or filters to see all transactions."
                } else {
                    "Start tracking your daily expenses and income by tapping the button below."
                },
                buttonText = "Add Transaction",
                onButtonClick = onNavigateToAdd
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                groupedTransactions.forEach { (dateHeader, transactions) ->
                    item {
                        Text(
                            text = dateHeader,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                        )
                    }

                    items(transactions, key = { it.id }) { tx ->
                        val catEntity = catMap[tx.category.lowercase()]
                        TransactionListItem(
                            transaction = tx,
                            categoryEntity = catEntity,
                            onClick = { onTransactionClick(tx) }
                        )
                    }
                }
            }
        }
    }
}
