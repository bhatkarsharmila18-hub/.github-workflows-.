package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CategoryEntity
import com.example.data.ExpenseRepository
import com.example.data.TransactionEntity
import com.example.ui.model.CategorySpendingStat
import com.example.ui.model.DateRangeFilter
import com.example.ui.model.ExpenseUiState
import com.example.ui.model.MonthlyStat
import com.example.ui.model.TransactionTypeFilter
import com.example.util.CategoryHelper
import com.example.util.DateUtils
import com.example.util.QuickAddPreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ExpenseRepository

    private val _uiState = MutableStateFlow(ExpenseUiState())
    val uiState: StateFlow<ExpenseUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    private val _typeFilter = MutableStateFlow(TransactionTypeFilter.ALL)
    private val _categoryFilter = MutableStateFlow<String?>(null)
    private val _paymentFilter = MutableStateFlow<String?>(null)
    private val _dateRangeFilter = MutableStateFlow(DateRangeFilter.ALL)
    private val _selectedMonthKey = MutableStateFlow(DateUtils.getCurrentMonthKey())
    private val _isDarkMode = MutableStateFlow<Boolean?>(null)

    private var lastDeletedTransaction: TransactionEntity? = null

    init {
        val database = AppDatabase.getInstance(application)
        repository = ExpenseRepository(
            transactionDao = database.transactionDao(),
            categoryDao = database.categoryDao(),
            budgetDao = database.budgetDao()
        )

        viewModelScope.launch {
            repository.ensureDefaultCategories()
        }

        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            val dbFlow = combine(
                repository.allTransactions,
                repository.allCategories,
                repository.getBudgetForMonth(DateUtils.getCurrentMonthKey())
            ) { txs, cats, budgetEntity ->
                Triple(txs, cats, budgetEntity?.amount)
            }

            val filterFlow1 = combine(
                _searchQuery,
                _typeFilter,
                _categoryFilter
            ) { query, typeF, catF ->
                Triple(query, typeF, catF)
            }

            val filterFlow2 = combine(
                _paymentFilter,
                _dateRangeFilter,
                _isDarkMode
            ) { payF, dateF, dark ->
                RawDataTuple2(payF, dateF, dark)
            }

            combine(dbFlow, filterFlow1, filterFlow2) { (txs, cats, budgetAmount), (query, typeF, catF), t2 ->
                val t1 = RawDataTuple1(txs, cats, budgetAmount, query, typeF, catF)
                computeState(t1, t2)
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    private fun computeState(t1: RawDataTuple1, t2: RawDataTuple2): ExpenseUiState {
        val allTxs = t1.transactions
        val categories = t1.categories
        val monthlyBudget = t1.budgetAmount
        val query = t1.query.trim().lowercase()
        val typeFilter = t1.typeFilter
        val catFilter = t1.categoryFilter
        val payFilter = t2.paymentFilter
        val dateRangeFilter = t2.dateRangeFilter
        val isDarkMode = t2.isDarkMode

        var totalIncome = 0.0
        var totalExpense = 0.0
        var todayExpense = 0.0
        var thisMonthExpense = 0.0

        val startOfToday = DateUtils.getStartOfToday()
        val endOfToday = DateUtils.getEndOfToday()
        val startOfMonth = DateUtils.getStartOfMonth()
        val currentMonthKey = DateUtils.getCurrentMonthKey()

        for (tx in allTxs) {
            if (tx.type == "INCOME") {
                totalIncome += tx.amount
            } else {
                totalExpense += tx.amount
                if (tx.date in startOfToday..endOfToday) {
                    todayExpense += tx.amount
                }
                if (tx.date >= startOfMonth && DateUtils.getMonthKey(tx.date) == currentMonthKey) {
                    thisMonthExpense += tx.amount
                }
            }
        }

        val balance = totalIncome - totalExpense
        val savings = balance.coerceAtLeast(0.0)

        val budgetPercent = if (monthlyBudget != null && monthlyBudget > 0) {
            ((thisMonthExpense / monthlyBudget) * 100f).toFloat().coerceIn(0f, 200f)
        } else {
            0f
        }
        val budgetRem = if (monthlyBudget != null) {
            monthlyBudget - thisMonthExpense
        } else {
            0.0
        }

        // Filter transactions
        val filtered = allTxs.filter { tx ->
            val matchesType = when (typeFilter) {
                TransactionTypeFilter.ALL -> true
                TransactionTypeFilter.EXPENSE -> tx.type == "EXPENSE"
                TransactionTypeFilter.INCOME -> tx.type == "INCOME"
            }

            val matchesCat = catFilter == null || tx.category.equals(catFilter, ignoreCase = true)
            val matchesPay = payFilter == null || tx.paymentMethod.equals(payFilter, ignoreCase = true)

            val matchesDate = when (dateRangeFilter) {
                DateRangeFilter.ALL -> true
                DateRangeFilter.TODAY -> tx.date in startOfToday..endOfToday
                DateRangeFilter.THIS_WEEK -> tx.date >= DateUtils.getStartOfWeek()
                DateRangeFilter.THIS_MONTH -> tx.date >= startOfMonth
                DateRangeFilter.LAST_MONTH -> {
                    val cal = Calendar.getInstance().apply { add(Calendar.MONTH, -1) }
                    val lastMonthKey = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.time)
                    DateUtils.getMonthKey(tx.date) == lastMonthKey
                }
            }

            val matchesQuery = if (query.isEmpty()) {
                true
            } else {
                tx.note.lowercase().contains(query) ||
                        tx.category.lowercase().contains(query) ||
                        tx.paymentMethod.lowercase().contains(query) ||
                        tx.amount.toString().contains(query)
            }

            matchesType && matchesCat && matchesPay && matchesDate && matchesQuery
        }

        // Category stats (this month's expenses or all expenses if none this month)
        val monthExpenses = allTxs.filter { it.type == "EXPENSE" && it.date >= startOfMonth }
        val expensesForCategoryStats = if (monthExpenses.isNotEmpty()) monthExpenses else allTxs.filter { it.type == "EXPENSE" }
        val categoryTotals = mutableMapOf<String, Double>()
        for (tx in expensesForCategoryStats) {
            categoryTotals[tx.category] = (categoryTotals[tx.category] ?: 0.0) + tx.amount
        }
        val totalForStats = categoryTotals.values.sum().coerceAtLeast(1.0)
        val catEntitiesByName = categories.associateBy { it.name.lowercase() }

        val categoryStats = categoryTotals.entries
            .sortedByDescending { it.value }
            .map { entry ->
                val entity = catEntitiesByName[entry.key.lowercase()]
                val color = if (entity != null) CategoryHelper.parseColor(entity.colorHex) else CategoryHelper.parseColor("#3B82F6")
                val iconName = entity?.iconName ?: "category"
                val pct = ((entry.value / totalForStats) * 100.0).toFloat()
                CategorySpendingStat(
                    category = entry.key,
                    amount = entry.value,
                    percentage = pct,
                    color = color,
                    iconName = iconName
                )
            }

        // Monthly comparison stats (last 6 months)
        val monthlyStats = computeMonthlyStats(allTxs)

        return ExpenseUiState(
            transactions = allTxs,
            filteredTransactions = filtered,
            categories = categories,
            currentBalance = balance,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            savings = savings,
            todayExpense = todayExpense,
            thisMonthExpense = thisMonthExpense,
            monthlyBudget = monthlyBudget,
            budgetSpentPercentage = budgetPercent,
            budgetRemaining = budgetRem,
            categoryStats = categoryStats,
            monthlyStats = monthlyStats,
            searchQuery = t1.query,
            typeFilter = typeFilter,
            categoryFilter = catFilter,
            paymentFilter = payFilter,
            dateRangeFilter = dateRangeFilter,
            isDarkMode = isDarkMode,
            isLoading = false
        )
    }

    private fun computeMonthlyStats(allTxs: List<TransactionEntity>): List<MonthlyStat> {
        val monthFormat = SimpleDateFormat("MMM", Locale.getDefault())
        val keyFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val statsList = mutableListOf<MonthlyStat>()

        val calendar = Calendar.getInstance()
        for (i in 5 downTo 0) {
            val cal = (calendar.clone() as Calendar).apply {
                add(Calendar.MONTH, -i)
            }
            val key = keyFormat.format(cal.time)
            val label = monthFormat.format(cal.time)

            val monthTxs = allTxs.filter { DateUtils.getMonthKey(it.date) == key }
            val exp = monthTxs.filter { it.type == "EXPENSE" }.sumOf { it.amount }
            val inc = monthTxs.filter { it.type == "INCOME" }.sumOf { it.amount }

            statsList.add(
                MonthlyStat(
                    monthKey = key,
                    monthLabel = label,
                    totalExpense = exp,
                    totalIncome = inc
                )
            )
        }
        return statsList
    }

    // Actions
    fun addTransaction(
        type: String,
        amount: Double,
        category: String,
        paymentMethod: String,
        date: Long = System.currentTimeMillis(),
        note: String = "",
        isRecurring: Boolean = false,
        recurringFrequency: String = "NONE",
        onComplete: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            repository.insertTransaction(
                TransactionEntity(
                    type = type,
                    amount = amount,
                    category = category,
                    paymentMethod = paymentMethod,
                    date = date,
                    note = note,
                    isRecurring = isRecurring,
                    recurringFrequency = recurringFrequency
                )
            )
            onComplete?.invoke()
        }
    }

    fun quickAdd(preset: QuickAddPreset, onComplete: (() -> Unit)? = null) {
        addTransaction(
            type = preset.type,
            amount = preset.amount,
            category = preset.category,
            paymentMethod = preset.paymentMethod,
            date = System.currentTimeMillis(),
            note = preset.title,
            onComplete = onComplete
        )
    }

    fun updateTransaction(transaction: TransactionEntity, onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.updateTransaction(transaction)
            onComplete?.invoke()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity, onComplete: ((TransactionEntity) -> Unit)? = null) {
        lastDeletedTransaction = transaction
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            onComplete?.invoke(transaction)
        }
    }

    fun undoDeleteTransaction() {
        val toRestore = lastDeletedTransaction ?: return
        viewModelScope.launch {
            repository.insertTransaction(toRestore)
            lastDeletedTransaction = null
        }
    }

    fun setMonthlyBudget(amount: Double) {
        viewModelScope.launch {
            repository.setBudget(DateUtils.getCurrentMonthKey(), amount)
        }
    }

    fun addCustomCategory(name: String, type: String, iconName: String, colorHex: String) {
        viewModelScope.launch {
            repository.insertCategory(
                CategoryEntity(
                    name = name.trim(),
                    type = type,
                    iconName = iconName,
                    colorHex = colorHex,
                    isCustom = true
                )
            )
        }
    }

    fun deleteCustomCategory(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomCategoryById(id)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllTransactions()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setTypeFilter(filter: TransactionTypeFilter) {
        _typeFilter.value = filter
    }

    fun setCategoryFilter(category: String?) {
        _categoryFilter.value = category
    }

    fun setPaymentFilter(method: String?) {
        _paymentFilter.value = method
    }

    fun setDateRangeFilter(filter: DateRangeFilter) {
        _dateRangeFilter.value = filter
    }

    fun toggleDarkMode(enabled: Boolean?) {
        _isDarkMode.value = enabled
    }

    fun exportCsv(): String {
        return repository.generateCsv(_uiState.value.transactions)
    }

    fun exportBackupJson(): String {
        return repository.exportBackupJson(
            _uiState.value.transactions,
            _uiState.value.categories
        )
    }

    suspend fun restoreBackupJson(jsonString: String): Int {
        return repository.restoreBackupJson(jsonString)
    }
}

private data class RawDataTuple1(
    val transactions: List<TransactionEntity>,
    val categories: List<CategoryEntity>,
    val budgetAmount: Double?,
    val query: String,
    val typeFilter: TransactionTypeFilter,
    val categoryFilter: String?
)

private data class RawDataTuple2(
    val paymentFilter: String?,
    val dateRangeFilter: DateRangeFilter,
    val isDarkMode: Boolean?
)
