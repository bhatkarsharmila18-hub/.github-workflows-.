package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald Brand Palette
val EmeraldPrimaryLight = Color(0xFF047857)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldPrimaryContainerLight = Color(0xFFD1FAE5)
val EmeraldOnPrimaryContainerLight = Color(0xFF064E3B)

val EmeraldPrimaryDark = Color(0xFF34D399)
val EmeraldOnPrimaryDark = Color(0xFF064E3B)
val EmeraldPrimaryContainerDark = Color(0xFF065F46)
val EmeraldOnPrimaryContainerDark = Color(0xFFA7F3D0)

val SlateSecondaryLight = Color(0xFF0F766E)
val SlateSecondaryDark = Color(0xFF2DD4BF)

val AmberTertiaryLight = Color(0xFFD97706)
val AmberTertiaryDark = Color(0xFFFBBF24)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

// Semantic Financial Indicators
val IncomeGreen = Color(0xFF10B981)
val ExpenseRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)
val InfoBlue = Color(0xFF3B82F6)
