package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object CurrencyUtils {
    // Formats amount with standard Indian Rupees formatting: e.g., ₹1,250.00 or ₹50,000.00
    fun formatInr(amount: Double, includeDecimals: Boolean = true): String {
        val symbols = DecimalFormatSymbols(Locale("en", "IN"))
        symbols.currencySymbol = "₹"
        
        val pattern = if (includeDecimals) {
            "₹#,##,##0.00"
        } else {
            "₹#,##,##0"
        }
        
        return try {
            val formatter = DecimalFormat(pattern, symbols)
            formatter.format(amount)
        } catch (_: Exception) {
            String.format(Locale.getDefault(), "₹%.2f", amount)
        }
    }

    fun parseAmount(input: String): Double? {
        val clean = input.trim().replace("₹", "").replace(",", "")
        return clean.toDoubleOrNull()
    }
}
