package com.example.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalGroceryStore
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class QuickAddPreset(
    val title: String,
    val amount: Double,
    val category: String,
    val paymentMethod: String,
    val type: String = "EXPENSE"
)

object CategoryHelper {
    val paymentMethods = listOf("Cash", "UPI", "Card", "Bank", "Other")

    val defaultQuickPresets = listOf(
        QuickAddPreset("Chai / Coffee", 20.0, "Food", "UPI"),
        QuickAddPreset("Lunch", 120.0, "Food", "UPI"),
        QuickAddPreset("Metro / Bus", 40.0, "Travel", "UPI"),
        QuickAddPreset("Fuel / Petrol", 200.0, "Travel", "Card"),
        QuickAddPreset("Groceries", 350.0, "Groceries", "UPI"),
        QuickAddPreset("Mobile Recharge", 299.0, "Bills", "UPI")
    )

    val availableIconNames = listOf(
        "restaurant", "fastfood", "flight", "directions_car", "local_gas_station",
        "shopping_bag", "shopping_cart", "school", "receipt_long", "movie",
        "medical_services", "local_hospital", "local_grocery_store", "work",
        "store", "trending_up", "card_giftcard", "phone_android", "more_horiz"
    )

    val availableColorHexes = listOf(
        "#EF4444", "#F97316", "#F59E0B", "#10B981", "#06B6D4",
        "#3B82F6", "#6366F1", "#8B5CF6", "#EC4899", "#64748B"
    )

    fun getIconVector(iconName: String): ImageVector {
        return when (iconName.lowercase()) {
            "restaurant" -> Icons.Default.Restaurant
            "fastfood" -> Icons.Default.Fastfood
            "flight" -> Icons.Default.Flight
            "directions_car" -> Icons.Default.DirectionsCar
            "local_gas_station" -> Icons.Default.LocalGasStation
            "shopping_bag" -> Icons.Default.ShoppingBag
            "shopping_cart" -> Icons.Default.ShoppingCart
            "school" -> Icons.Default.School
            "receipt", "receipt_long" -> Icons.Default.ReceiptLong
            "movie" -> Icons.Default.Movie
            "medical_services", "health" -> Icons.Default.MedicalServices
            "local_hospital" -> Icons.Default.LocalHospital
            "local_grocery_store", "groceries" -> Icons.Default.LocalGroceryStore
            "account_balance_wallet" -> Icons.Default.AccountBalanceWallet
            "work" -> Icons.Default.Work
            "store" -> Icons.Default.Store
            "trending_up" -> Icons.Default.TrendingUp
            "card_giftcard" -> Icons.Default.CardGiftcard
            "attach_money", "money" -> Icons.Default.MonetizationOn
            "phone_android" -> Icons.Default.PhoneAndroid
            "credit_card" -> Icons.Default.CreditCard
            "account_balance" -> Icons.Default.AccountBalance
            else -> Icons.Default.Category
        }
    }

    fun parseColor(hex: String, fallback: Color = Color(0xFF3B82F6)): Color {
        return try {
            val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
            Color(android.graphics.Color.parseColor(cleanHex))
        } catch (_: Exception) {
            fallback
        }
    }

    fun getPaymentMethodIcon(method: String): ImageVector {
        return when (method.lowercase()) {
            "cash" -> Icons.Default.Money
            "upi" -> Icons.Default.PhoneAndroid
            "card" -> Icons.Default.CreditCard
            "bank" -> Icons.Default.AccountBalance
            else -> Icons.Default.Payments
        }
    }
}
