package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ExpenseRepository
import com.example.data.TransactionEntity
import com.example.util.CurrencyUtils
import com.example.util.DateUtils
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: ExpenseRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ExpenseRepository(
            transactionDao = database.transactionDao(),
            categoryDao = database.categoryDao(),
            budgetDao = database.budgetDao()
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testCompleteExpenseTrackerFlow() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Expense Tracker", appName)

        // Step 1: Ensure categories populated
        repository.ensureDefaultCategories()
        val initialCategories = repository.allCategories.first()
        assertTrue("Categories should not be empty", initialCategories.isNotEmpty())

        // Step 2: Add Income
        val incomeId = repository.insertTransaction(
            TransactionEntity(
                type = "INCOME",
                amount = 50000.0,
                category = "Salary",
                paymentMethod = "Bank",
                date = System.currentTimeMillis(),
                note = "October Monthly Salary"
            )
        )
        assertTrue(incomeId > 0)

        // Step 3: Add Expenses
        val expenseFoodId = repository.insertTransaction(
            TransactionEntity(
                type = "EXPENSE",
                amount = 500.0,
                category = "Food",
                paymentMethod = "UPI",
                date = System.currentTimeMillis(),
                note = "Team Dinner"
            )
        )
        val expenseTravelId = repository.insertTransaction(
            TransactionEntity(
                type = "EXPENSE",
                amount = 200.0,
                category = "Travel",
                paymentMethod = "Card",
                date = System.currentTimeMillis(),
                note = "Metro recharge"
            )
        )
        assertTrue(expenseFoodId > 0 && expenseTravelId > 0)

        // Step 4: Verify Dashboard Totals
        val txList = repository.allTransactions.first()
        assertEquals(3, txList.size)

        val totalIncome = txList.filter { it.type == "INCOME" }.sumOf { it.amount }
        val totalExpense = txList.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val balance = totalIncome - totalExpense

        assertEquals(50000.0, totalIncome, 0.001)
        assertEquals(700.0, totalExpense, 0.001)
        assertEquals(49300.0, balance, 0.001)

        // Step 5: Test Indian Currency Formatting
        val formatted = CurrencyUtils.formatInr(balance)
        assertTrue("Currency should contain ₹ symbol", formatted.contains("₹"))

        // Step 6: Test Monthly Budget
        val currentMonthKey = DateUtils.getCurrentMonthKey()
        repository.setBudget(currentMonthKey, 20000.0)
        val budget = repository.getBudgetForMonth(currentMonthKey).first()
        assertNotNull(budget)
        assertEquals(20000.0, budget!!.amount, 0.001)
        val remainingBudget = budget.amount - totalExpense
        assertEquals(19300.0, remainingBudget, 0.001)

        // Step 7: Test Edit Transaction
        val foodTx = database.transactionDao().getTransactionById(expenseFoodId)
        assertNotNull(foodTx)
        repository.updateTransaction(foodTx!!.copy(amount = 650.0, note = "Dinner with dessert"))
        val updatedFoodTx = database.transactionDao().getTransactionById(expenseFoodId)
        assertEquals(650.0, updatedFoodTx!!.amount, 0.001)
        assertEquals("Dinner with dessert", updatedFoodTx.note)

        // Step 8: Test Delete and Undo
        val travelTx = database.transactionDao().getTransactionById(expenseTravelId)
        assertNotNull(travelTx)
        repository.deleteTransaction(travelTx!!)
        assertEquals(2, repository.allTransactions.first().size)
        // Re-insert (Undo)
        repository.insertTransaction(travelTx)
        assertEquals(3, repository.allTransactions.first().size)

        // Step 9: Test CSV Generation
        val csv = repository.generateCsv(repository.allTransactions.first())
        assertTrue("CSV header present", csv.contains("ID,Date,Type,Category,Amount"))
        assertTrue("CSV contains Salary", csv.contains("Salary"))
        assertTrue("CSV contains Food", csv.contains("Food"))

        // Step 10: Test JSON Backup & Restore
        val backupJson = repository.exportBackupJson(
            repository.allTransactions.first(),
            repository.allCategories.first()
        )
        assertTrue(backupJson.contains("\"transactions\""))

        // Clear and Restore
        repository.clearAllTransactions()
        assertEquals(0, repository.allTransactions.first().size)
        val restoredCount = repository.restoreBackupJson(backupJson)
        assertEquals(3, restoredCount)
        assertEquals(3, repository.allTransactions.first().size)
    }
}
